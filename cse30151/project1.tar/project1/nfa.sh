#!/bin/sh
python nfa.py $1